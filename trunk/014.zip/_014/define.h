#define X_Axis      0
#define Y_Axis      1
#define Z_Axis      2

#define ACC_ORIENTATION(X, Y, Z)  {accADC[X_Axis]  = -Y; accADC[Y_Axis]  =  X; accADC[Z_Axis]  =  Z;}
#define GYRO_ORIENTATION(X, Y, Z) {gyroADC[X_Axis] = -X; gyroADC[Y_Axis] = -Y; gyroADC[Z_Axis] = -Z;}

#define I2C_PULLUPS_DISABLE        PORTC &= ~(1<<4); PORTC &= ~(1<<5);
#define SPEK_SERIAL_VECT           USART_RX_vect
#define SPEK_DATA_REG              UDR0

#define millis_divider 64
#define micros_divider 64


